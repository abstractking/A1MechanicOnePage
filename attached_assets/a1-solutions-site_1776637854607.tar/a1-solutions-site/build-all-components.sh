#!/bin/bash

# Create Navbar Component
cat > src/components/Navbar.tsx << 'EOF'
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import styles from './Navbar.module.css';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.nav
      className={`${styles.navbar} ${scrolled ? styles.scrolled : ''}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className={styles.container}>
        <motion.div
          className={styles.logo}
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        >
          <span className={styles.logoGear}>⚙️</span>
          <div className={styles.logoText}>
            <span className={styles.logoMain}>A1 SOLUTIONS</span>
            <span className={styles.logoSub}>24 HR MOBILE MECHANIC</span>
          </div>
        </motion.div>
        
        <div className={styles.menu}>
          <button onClick={() => scrollToSection('services')} className={styles.menuItem}>
            Services
          </button>
          <button onClick={() => scrollToSection('about')} className={styles.menuItem}>
            About
          </button>
          <button onClick={() => scrollToSection('coverage')} className={styles.menuItem}>
            Coverage
          </button>
          <button onClick={() => scrollToSection('contact')} className={styles.menuItem}>
            Contact
          </button>
        </div>

        <motion.a
          href="tel:1-409-779-7780"
          className={styles.cta}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
        >
          <span className={styles.ctaIcon}>📞</span>
          <span>CALL NOW</span>
        </motion.a>
      </div>
    </motion.nav>
  );
};

export default Navbar;
EOF

# Navbar CSS
cat > src/components/Navbar.module.css << 'EOF'
.navbar {
  position: sticky;
  top: 0;
  z-index: 1000;
  background: rgba(13, 13, 13, 0.95);
  backdrop-filter: blur(10px);
  border-bottom: 3px solid var(--color-orange-primary);
  padding: 1rem 0;
  transition: all 0.3s var(--ease-snap);
}

.navbar.scrolled {
  background: rgba(13, 13, 13, 0.98);
  box-shadow: 0 4px 20px rgba(255, 140, 0, 0.3);
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.logo {
  display: flex;
  align-items: center;
  gap: 1rem;
  cursor: pointer;
}

.logoGear {
  font-size: 2.5rem;
  animation: spin 20s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.logoText {
  display: flex;
  flex-direction: column;
  gap: 0.125rem;
}

.logoMain {
  font-family: var(--font-display);
  font-size: 1.5rem;
  color: var(--color-orange-primary);
  font-weight: 700;
  letter-spacing: 2px;
}

.logoSub {
  font-family: var(--font-display);
  font-size: 0.75rem;
  color: var(--color-silver);
  font-weight: 500;
  letter-spacing: 1.5px;
}

.menu {
  display: flex;
  gap: 2.5rem;
}

.menuItem {
  background: transparent;
  color: var(--color-silver);
  font-size: 1rem;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 1px;
  transition: all 0.2s ease;
  position: relative;
  font-family: var(--font-display);
}

.menuItem::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 0;
  width: 0;
  height: 2px;
  background: var(--color-orange-primary);
  transition: width 0.3s var(--ease-spring);
}

.menuItem:hover {
  color: var(--color-orange-primary);
}

.menuItem:hover::after {
  width: 100%;
}

.cta {
  background: var(--color-orange-primary);
  color: var(--color-black);
  padding: 0.875rem 2rem;
  font-weight: 700;
  font-family: var(--font-display);
  letter-spacing: 1px;
  font-size: 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  transition: all 0.2s var(--ease-snap);
  box-shadow: 0 4px 12px rgba(255, 140, 0, 0.4);
}

.cta:hover {
  background: var(--color-orange-light);
  box-shadow: 0 6px 16px rgba(255, 140, 0, 0.6);
}

.ctaIcon {
  font-size: 1.25rem;
}

@media (max-width: 768px) {
  .menu {
    display: none;
  }
  
  .container {
    padding: 0 1rem;
  }
  
  .logoMain {
    font-size: 1.25rem;
  }
  
  .logoSub {
    font-size: 0.625rem;
  }
  
  .logoGear {
    font-size: 2rem;
  }
  
  .cta {
    padding: 0.75rem 1.5rem;
    font-size: 0.875rem;
  }
}
EOF

echo "Navbar created"
