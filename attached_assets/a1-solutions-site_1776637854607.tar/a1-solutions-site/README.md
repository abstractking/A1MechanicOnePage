# A1 Solutions 24 - Mobile Mechanic Website

Industrial retrofuturism design with orange/black color scheme, spinning gears, and high-energy animations.

## 🔧 About A1 Solutions

**Service:** 24/7 Mobile Mechanic  
**Phone:** 1-409-779-7780  
**Email:** willwork1971@gmail.com  
**Coverage:** Texas & Louisiana  
**Tagline:** "You have a problem? We are the SOLUTION"

## 🎨 Design: Retrofuturism + Kinetic Motion (70/30)

- **Industrial Orange/Black Palette**: Matching client's exact branding
- **Animated Gears**: Spinning gear elements throughout
- **Metallic Textures**: Dark grays with orange accents
- **High Energy**: Fast, snappy animations
- **24/7 Focus**: Emergency service emphasis

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Visit http://localhost:5173

## 📦 Build

```bash
npm run build
```

## 🎯 Features

- Spinning gear animations
- Industrial orange (#FF8C00) and black (#0D0D0D) color scheme
- Click-to-call CTAs
- Mobile-first responsive design
- Smooth scroll navigation
- Framer Motion animations

---

**Built for:** A1 Solutions 24 HR Mobile Mechanic  
**Design Style:** Retrofuturism + Kinetic Motion  
**Colors:** Orange/Black (from client branding)
