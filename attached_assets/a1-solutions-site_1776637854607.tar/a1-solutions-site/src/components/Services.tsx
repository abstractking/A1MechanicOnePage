import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import styles from './Services.module.css';

const services = [
  {
    title: '24/7 Emergency Roadside Repair',
    description: 'Stranded? We come to you. Fast response for breakdowns, flat tires, battery jumps, and emergency mechanical issues.',
    icon: '🚨'
  },
  {
    title: 'Complete Vehicle Diagnostics',
    description: 'Advanced diagnostic equipment to identify and repair engine, transmission, electrical, and computer system problems.',
    icon: '🔍'
  },
  {
    title: 'Engine Repair & Maintenance',
    description: 'Expert engine work including oil changes, tune-ups, belt replacement, and major engine overhauls.',
    icon: '⚙️'
  },
  {
    title: 'Brake System Service',
    description: 'Complete brake inspection, pad/rotor replacement, fluid service, and ABS system diagnostics and repair.',
    icon: '🛑'
  },
  {
    title: 'Electrical System Repair',
    description: 'Battery testing and replacement, alternator repair, starter service, and complete electrical troubleshooting.',
    icon: '⚡'
  },
  {
    title: 'On-Site Fleet Maintenance',
    description: 'Mobile maintenance programs for commercial fleets. Keep your vehicles running without downtime.',
    icon: '🚛'
  }
];

const Services = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="services" className={styles.services} ref={ref}>
      <div className={styles.container}>
        <motion.div
          className={styles.header}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <h2 className={styles.title}>OUR SERVICES</h2>
          <p className={styles.subtitle}>
            Professional mobile mechanic services — We bring the shop to you
          </p>
        </motion.div>

        <div className={styles.grid}>
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              className={styles.card}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ 
                duration: 0.5, 
                ease: [0.22, 1, 0.36, 1],
                delay: index * 0.1
              }}
              whileHover={{ 
                y: -8,
                transition: { duration: 0.2 }
              }}
            >
              <div className={styles.icon}>{service.icon}</div>
              <h3 className={styles.cardTitle}>{service.title}</h3>
              <p className={styles.cardDescription}>{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
