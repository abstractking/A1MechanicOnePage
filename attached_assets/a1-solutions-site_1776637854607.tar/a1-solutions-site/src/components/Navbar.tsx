import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import styles from './Navbar.module.css';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.nav
      className={`${styles.navbar} ${scrolled ? styles.scrolled : ''}`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className={styles.container}>
        <motion.div
          className={styles.logo}
          whileHover={{ scale: 1.05 }}
          transition={{ duration: 0.2 }}
        >
          <span className={styles.logoGear}>⚙️</span>
          <div className={styles.logoText}>
            <span className={styles.logoMain}>A1 SOLUTIONS</span>
            <span className={styles.logoSub}>24 HR MOBILE MECHANIC</span>
          </div>
        </motion.div>
        
        <div className={styles.menu}>
          <button onClick={() => scrollToSection('services')} className={styles.menuItem}>
            Services
          </button>
          <button onClick={() => scrollToSection('about')} className={styles.menuItem}>
            About
          </button>
          <button onClick={() => scrollToSection('coverage')} className={styles.menuItem}>
            Coverage
          </button>
          <button onClick={() => scrollToSection('contact')} className={styles.menuItem}>
            Contact
          </button>
        </div>

        <motion.a
          href="tel:1-409-779-7780"
          className={styles.cta}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
        >
          <span className={styles.ctaIcon}>📞</span>
          <span>CALL NOW</span>
        </motion.a>
      </div>
    </motion.nav>
  );
};

export default Navbar;
