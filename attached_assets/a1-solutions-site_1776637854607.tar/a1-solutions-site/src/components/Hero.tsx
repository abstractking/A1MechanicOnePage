import { motion } from 'framer-motion';
import styles from './Hero.module.css';

const Hero = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className={styles.hero}>
      <div className={styles.gearBackground}>
        <div className={styles.gear1}>⚙️</div>
        <div className={styles.gear2}>⚙️</div>
        <div className={styles.gear3}>⚙️</div>
      </div>
      
      <div className={styles.container}>
        <motion.div
          className={styles.content}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        >
          <motion.h1
            className={styles.headline}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
          >
            <span className={styles.headlineTop}>YOU HAVE A PROBLEM?</span>
            <span className={styles.headlineMain}>WE ARE THE</span>
            <span className={styles.headlineHighlight}>SOLUTION</span>
          </motion.h1>
          
          <motion.p
            className={styles.tagline}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.6 }}
          >
            24/7 Mobile Mechanic Service — Emergency Roadside Repair & Automotive Solutions
          </motion.p>
          
          <motion.div
            className={styles.ctaGroup}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.8 }}
          >
            <motion.a
              href="tel:1-409-779-7780"
              className={styles.primaryCta}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className={styles.ctaIcon}>📞</span>
              <div className={styles.ctaText}>
                <span className={styles.ctaLabel}>CALL BILL NOW</span>
                <span className={styles.ctaPhone}>1-409-779-7780</span>
              </div>
            </motion.a>
            
            <motion.button
              className={styles.secondaryCta}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={scrollToContact}
            >
              REQUEST SERVICE
            </motion.button>
          </motion.div>
          
          <motion.div
            className={styles.badges}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>⚡</span>
              <span>24/7 Available</span>
            </div>
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>🚗</span>
              <span>Mobile Service</span>
            </div>
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>🔧</span>
              <span>Expert Repairs</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
