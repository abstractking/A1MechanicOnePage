import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Hero />
      <Services />
      <div style={{
        background: 'var(--color-orange-primary)',
        color: 'var(--color-black)',
        padding: '4rem 2rem',
        textAlign: 'center',
        fontFamily: 'var(--font-display)',
        fontSize: '2rem',
        fontWeight: 700,
        letterSpacing: '2px'
      }}>
        MORE SECTIONS COMING SOON...
        <div style={{marginTop: '2rem', fontSize: '1.5rem'}}>
          CALL BILL: 1-409-779-7780
        </div>
      </div>
    </div>
  );
}

export default App;
