#!/bin/bash

# Create Hero Component with spinning gears
cat > src/components/Hero.tsx << 'EOF'
import { motion } from 'framer-motion';
import styles from './Hero.module.css';

const Hero = () => {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className={styles.hero}>
      <div className={styles.gearBackground}>
        <div className={styles.gear1}>⚙️</div>
        <div className={styles.gear2}>⚙️</div>
        <div className={styles.gear3}>⚙️</div>
      </div>
      
      <div className={styles.container}>
        <motion.div
          className={styles.content}
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1], delay: 0.2 }}
        >
          <motion.h1
            className={styles.headline}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.4 }}
          >
            <span className={styles.headlineTop}>YOU HAVE A PROBLEM?</span>
            <span className={styles.headlineMain}>WE ARE THE</span>
            <span className={styles.headlineHighlight}>SOLUTION</span>
          </motion.h1>
          
          <motion.p
            className={styles.tagline}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.6 }}
          >
            24/7 Mobile Mechanic Service — Emergency Roadside Repair & Automotive Solutions
          </motion.p>
          
          <motion.div
            className={styles.ctaGroup}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1], delay: 0.8 }}
          >
            <motion.a
              href="tel:1-409-779-7780"
              className={styles.primaryCta}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
            >
              <span className={styles.ctaIcon}>📞</span>
              <div className={styles.ctaText}>
                <span className={styles.ctaLabel}>CALL BILL NOW</span>
                <span className={styles.ctaPhone}>1-409-779-7780</span>
              </div>
            </motion.a>
            
            <motion.button
              className={styles.secondaryCta}
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={scrollToContact}
            >
              REQUEST SERVICE
            </motion.button>
          </motion.div>
          
          <motion.div
            className={styles.badges}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 1 }}
          >
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>⚡</span>
              <span>24/7 Available</span>
            </div>
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>🚗</span>
              <span>Mobile Service</span>
            </div>
            <div className={styles.badge}>
              <span className={styles.badgeIcon}>🔧</span>
              <span>Expert Repairs</span>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
EOF

# Hero CSS with gear animations
cat > src/components/Hero.module.css << 'EOF'
.hero {
  min-height: 90vh;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #0D0D0D 0%, #1A1A1A 50%, #2D2D2D 100%);
  position: relative;
  overflow: hidden;
  padding: 4rem 0;
  border-bottom: 4px solid var(--color-orange-primary);
}

.gearBackground {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  opacity: 0.1;
  overflow: hidden;
  pointer-events: none;
}

.gear1, .gear2, .gear3 {
  position: absolute;
  font-size: 15rem;
  animation: spin 30s linear infinite;
  color: var(--color-orange-primary);
}

.gear1 {
  top: -100px;
  left: -100px;
}

.gear2 {
  bottom: -150px;
  right: -100px;
  animation-direction: reverse;
  animation-duration: 40s;
}

.gear3 {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  font-size: 20rem;
  opacity: 0.05;
  animation-duration: 50s;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 2rem;
  position: relative;
  z-index: 10;
}

.content {
  text-align: center;
  max-width: 900px;
  margin: 0 auto;
}

.headline {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 2rem;
}

.headlineTop {
  font-size: clamp(1.5rem, 4vw, 2.5rem);
  color: var(--color-silver);
  font-weight: 500;
  letter-spacing: 3px;
}

.headlineMain {
  font-size: clamp(2.5rem, 7vw, 5rem);
  color: var(--color-white);
  font-weight: 700;
  letter-spacing: 4px;
}

.headlineHighlight {
  font-size: clamp(3rem, 9vw, 6.5rem);
  color: var(--color-orange-primary);
  font-weight: 700;
  letter-spacing: 6px;
  text-shadow: 0 0 30px rgba(255, 140, 0, 0.5);
}

.tagline {
  font-size: clamp(1.125rem, 2vw, 1.5rem);
  color: var(--color-silver);
  margin-bottom: 3rem;
  line-height: 1.6;
  max-width: 700px;
  margin-left: auto;
  margin-right: auto;
}

.ctaGroup {
  display: flex;
  gap: 1.5rem;
  justify-content: center;
  flex-wrap: wrap;
  margin-bottom: 3rem;
}

.primaryCta {
  background: var(--color-orange-primary);
  color: var(--color-black);
  padding: 1.5rem 3rem;
  display: flex;
  align-items: center;
  gap: 1rem;
  transition: all 0.2s var(--ease-snap);
  box-shadow: 0 6px 24px rgba(255, 140, 0, 0.4);
  border: 3px solid var(--color-orange-light);
}

.primaryCta:hover {
  background: var(--color-orange-light);
  box-shadow: 0 8px 32px rgba(255, 140, 0, 0.6);
}

.ctaIcon {
  font-size: 2.5rem;
}

.ctaText {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 0.25rem;
}

.ctaLabel {
  font-family: var(--font-display);
  font-size: 0.875rem;
  font-weight: 600;
  letter-spacing: 2px;
}

.ctaPhone {
  font-family: var(--font-display);
  font-size: 1.5rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.secondaryCta {
  background: transparent;
  color: var(--color-orange-primary);
  padding: 1.5rem 3rem;
  font-size: 1.125rem;
  font-weight: 700;
  font-family: var(--font-display);
  letter-spacing: 2px;
  border: 3px solid var(--color-orange-primary);
  transition: all 0.2s var(--ease-snap);
}

.secondaryCta:hover {
  background: var(--color-orange-primary);
  color: var(--color-black);
}

.badges {
  display: flex;
  gap: 2.5rem;
  justify-content: center;
  flex-wrap: wrap;
}

.badge {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  color: var(--color-silver);
  font-weight: 600;
  font-size: 1.125rem;
  font-family: var(--font-display);
  letter-spacing: 1px;
}

.badgeIcon {
  font-size: 1.75rem;
}

@media (max-width: 768px) {
  .hero {
    min-height: 80vh;
    padding: 3rem 0;
  }
  
  .container {
    padding: 0 1rem;
  }
  
  .ctaGroup {
    flex-direction: column;
    align-items: center;
  }
  
  .primaryCta,
  .secondaryCta {
    width: 100%;
    max-width: 350px;
    justify-content: center;
  }
  
  .badges {
    flex-direction: column;
    gap: 1.5rem;
  }
  
  .gear1, .gear2, .gear3 {
    font-size: 8rem;
  }
}
EOF

echo "Hero component created with spinning gears!"
