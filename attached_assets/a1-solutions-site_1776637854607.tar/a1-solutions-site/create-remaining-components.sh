#!/bin/bash

# Services Component
cat > src/components/Services.tsx << 'SERVEOF'
import { motion } from 'framer-motion';
import { useInView } from 'framer-motion';
import { useRef } from 'react';
import styles from './Services.module.css';

const services = [
  {
    title: '24/7 Emergency Roadside Repair',
    description: 'Stranded? We come to you. Fast response for breakdowns, flat tires, battery jumps, and emergency mechanical issues.',
    icon: '🚨'
  },
  {
    title: 'Complete Vehicle Diagnostics',
    description: 'Advanced diagnostic equipment to identify and repair engine, transmission, electrical, and computer system problems.',
    icon: '🔍'
  },
  {
    title: 'Engine Repair & Maintenance',
    description: 'Expert engine work including oil changes, tune-ups, belt replacement, and major engine overhauls.',
    icon: '⚙️'
  },
  {
    title: 'Brake System Service',
    description: 'Complete brake inspection, pad/rotor replacement, fluid service, and ABS system diagnostics and repair.',
    icon: '🛑'
  },
  {
    title: 'Electrical System Repair',
    description: 'Battery testing and replacement, alternator repair, starter service, and complete electrical troubleshooting.',
    icon: '⚡'
  },
  {
    title: 'On-Site Fleet Maintenance',
    description: 'Mobile maintenance programs for commercial fleets. Keep your vehicles running without downtime.',
    icon: '🚛'
  }
];

const Services = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  return (
    <section id="services" className={styles.services} ref={ref}>
      <div className={styles.container}>
        <motion.div
          className={styles.header}
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        >
          <h2 className={styles.title}>OUR SERVICES</h2>
          <p className={styles.subtitle}>
            Professional mobile mechanic services — We bring the shop to you
          </p>
        </motion.div>

        <div className={styles.grid}>
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              className={styles.card}
              initial={{ opacity: 0, y: 40 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ 
                duration: 0.5, 
                ease: [0.22, 1, 0.36, 1],
                delay: index * 0.1
              }}
              whileHover={{ 
                y: -8,
                transition: { duration: 0.2 }
              }}
            >
              <div className={styles.icon}>{service.icon}</div>
              <h3 className={styles.cardTitle}>{service.title}</h3>
              <p className={styles.cardDescription}>{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
SERVEOF

# Services CSS
cat > src/components/Services.module.css << 'SERVECSS'
.services {
  padding: var(--spacing-xl) 0;
  background: var(--color-dark-gray);
}

.container {
  max-width: 1400px;
  margin: 0 auto;
  padding: 0 2rem;
}

.header {
  text-align: center;
  margin-bottom: var(--spacing-lg);
}

.title {
  font-size: clamp(2.5rem, 6vw, 4rem);
  color: var(--color-orange-primary);
  margin-bottom: 1rem;
  letter-spacing: 4px;
}

.subtitle {
  font-size: clamp(1rem, 2vw, 1.25rem);
  color: var(--color-silver);
  max-width: 600px;
  margin: 0 auto;
}

.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 2rem;
}

.card {
  background: var(--color-metal-gray);
  padding: 2.5rem 2rem;
  border: 2px solid var(--color-light-gray);
  transition: all 0.3s var(--ease-snap);
  cursor: default;
}

.card:hover {
  border-color: var(--color-orange-primary);
  box-shadow: 0 8px 24px rgba(255, 140, 0, 0.2);
}

.icon {
  font-size: 3.5rem;
  margin-bottom: 1.5rem;
}

.cardTitle {
  font-size: clamp(1.25rem, 2.5vw, 1.5rem);
  color: var(--color-white);
  margin-bottom: 1rem;
  font-weight: 700;
  letter-spacing: 1px;
}

.cardDescription {
  font-size: 1rem;
  line-height: 1.7;
  color: var(--color-silver);
}

@media (max-width: 768px) {
  .services {
    padding: var(--spacing-lg) 0;
  }
  
  .container {
    padding: 0 1rem;
  }
  
  .grid {
    grid-template-columns: 1fr;
  }
}
SERVECSS

# Create App.tsx
cat > src/App.tsx << 'APPEOF'
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Services from './components/Services';

function App() {
  return (
    <div className="App">
      <Navbar />
      <Hero />
      <Services />
      <div style={{
        background: 'var(--color-orange-primary)',
        color: 'var(--color-black)',
        padding: '4rem 2rem',
        textAlign: 'center',
        fontFamily: 'var(--font-display)',
        fontSize: '2rem',
        fontWeight: 700,
        letterSpacing: '2px'
      }}>
        MORE SECTIONS COMING SOON...
        <div style={{marginTop: '2rem', fontSize: '1.5rem'}}>
          CALL BILL: 1-409-779-7780
        </div>
      </div>
    </div>
  );
}

export default App;
APPEOF

# Create README
cat > README.md << 'READEOF'
# A1 Solutions 24 - Mobile Mechanic Website

Industrial retrofuturism design with orange/black color scheme, spinning gears, and high-energy animations.

## 🔧 About A1 Solutions

**Service:** 24/7 Mobile Mechanic  
**Phone:** 1-409-779-7780  
**Email:** willwork1971@gmail.com  
**Coverage:** Texas & Louisiana  
**Tagline:** "You have a problem? We are the SOLUTION"

## 🎨 Design: Retrofuturism + Kinetic Motion (70/30)

- **Industrial Orange/Black Palette**: Matching client's exact branding
- **Animated Gears**: Spinning gear elements throughout
- **Metallic Textures**: Dark grays with orange accents
- **High Energy**: Fast, snappy animations
- **24/7 Focus**: Emergency service emphasis

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Visit http://localhost:5173

## 📦 Build

```bash
npm run build
```

## 🎯 Features

- Spinning gear animations
- Industrial orange (#FF8C00) and black (#0D0D0D) color scheme
- Click-to-call CTAs
- Mobile-first responsive design
- Smooth scroll navigation
- Framer Motion animations

---

**Built for:** A1 Solutions 24 HR Mobile Mechanic  
**Design Style:** Retrofuturism + Kinetic Motion  
**Colors:** Orange/Black (from client branding)
READEOF

echo "All components created successfully!"
